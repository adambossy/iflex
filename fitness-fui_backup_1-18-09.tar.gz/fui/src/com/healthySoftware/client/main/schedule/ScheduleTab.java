package com.healthySoftware.client.main.schedule;

import java.util.Iterator;

import com.google.gwt.user.client.ui.Panel;
import com.google.gwt.user.client.ui.Widget;

public class ScheduleTab extends Panel {

	public ScheduleTab() {
		super();
	}
	
	@Override
	public boolean remove(Widget child) {
		// TODO Auto-generated method stub
		return false;
	}

	public Iterator<Widget> iterator() {
		// TODO Auto-generated method stub
		return null;
	}

}
