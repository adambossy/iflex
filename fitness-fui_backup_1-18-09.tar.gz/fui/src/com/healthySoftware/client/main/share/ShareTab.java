package com.healthySoftware.client.main.share;

import java.util.Iterator;

import com.google.gwt.user.client.ui.Panel;
import com.google.gwt.user.client.ui.Widget;

public class ShareTab extends Panel {

	public ShareTab() {
		super();
	}
	
	@Override
	public boolean remove(Widget child) {
		// TODO Auto-generated method stub
		return false;
	}

	public Iterator<Widget> iterator() {
		// TODO Auto-generated method stub
		return null;
	}

}
