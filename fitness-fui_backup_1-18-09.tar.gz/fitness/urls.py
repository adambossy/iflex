from django.conf.urls.defaults import *
from django.conf import settings
from django.contrib import admin
from fitness.workout.models import Workout
from fitness.members.models import Member
from fitness.exercises.models import ExerciseType

admin.autodiscover()

all_members_dict = {
    'queryset': Member.objects.all(),
}

#recent_workouts_dict = { 
#    'queryset': Workout.objects.all(),
#    'date_field': 'date',
#    'num_latest': 10,
#}

urlpatterns = patterns('',
                       # Workout
                       (r'^$', 'fitness.workout.views.index'),

                       (r'^workout/add/(?P<member_id>\d+)/$',
                        'fitness.workout.views.add'),

                       (r'^workout/add_workout/(?P<member_id>\d+)/$',
                        'fitness.workout.views.add_workout'),

                       (r'^workout/fetch_workout_template/(?P<member_id>\d+)/$',
                        'fitness.workout.views.fetch_workout_template'),

                       (r'^workout/profile/(?P<member_id>\d+)/$',
                        'fitness.workout.views.profile'),

                       (r'^workout/recent/(?P<member_id>\d+)/$',
                        'fitness.workout.views.recent'),

                       (r'^workout/details/(?P<member_id>\d+)/(?P<workout_id>\d+)/$',
                        'fitness.workout.views.details'),

                       # Exercises
                       (r'^exercises/$',
                        'fitness.exercises.views.default'),

                       (r'^exercises/add/$', 
                        'fitness.exercises.views.add'),

#                       (r'^exercises/addForm/$', 
#                        'fitness.exercises.views.addForm'),

#                       (r'^exercises/list/$', 
#                        'fitness.exercises.views.list'),

                       (r'^exercises/delete/(?P<exercise_id>\d+)/$', 
                        'fitness.exercises.views.delete'),

#                       (r'^exercises/script_init_workout_types/$',
#                        'fitness.exercises.views.script_init_workout_types'),

                       # Muscles
                       (r'^muscles/$',
                        'fitness.muscles.views.default'),

#                        (r'^muscles/default_muscle/$',
#                         'fitness.muscles.views.default_muscle'),

#                        (r'^muscles/default_muscle_group/$',
#                         'fitness.muscles.views.default_muscle_group'),

                        (r'^muscles/add/$', 
                         'fitness.muscles.views.add'),

#                        (r'^muscles/add_muscle_group/$', 
#                         'fitness.muscles.views.add_muscle_group'),

                        (r'^muscles/delete/(?P<muscle_id>\d+)/$', 
                         'fitness.muscles.views.delete'),

#                        (r'^muscles/delete_muscle_group/(?P<muscle_group_id>\d+)/$', 
#                         'fitness.muscles.views.delete_muscle_group'),

                       # Members
                       (r'^members/$', 'fitness.members.views.index'),

                       (r'^members/add/$', 'fitness.members.views.add'),

                       # Journal
                       (r'^journal/(?P<member_id>\d+)/$', 'fitness.journal.views.index'),

                       (r'^journal/$', 'fitness.journal.views.default'),

                       (r'^journal/add/(?P<member_id>\d+)/$', 'fitness.journal.views.add'),
#                       (r'^journal/add/$', 'fitness.journal.views.add'),

                       (r'^journal/addf/(?P<member_id>\d+)/$', 'fitness.journal.views.add'),

                       (r'^journal/delete/(?P<member_id>\d+)/(?P<journal_entry_id>\d+)/$',
                        'fitness.journal.views.delete'),

                       # Templates
                       # TODO: Should I even require a member id as an author or should I allow anonymous template creation
                       # using the session ID and IP (with some kind of spam restriction?)
                       (r'^template_editor/(?P<member_id>\d+)/$', 'fitness.template_editor.views.index'),

                       (r'^template_editor/save/(?P<member_id>\d+)/$', 'fitness.template_editor.views.save'),
                       
                       (r'^template_editor/load/$', 'fitness.template_editor.views.load'),
#                       (r'^template_editor/save/$', 'fitness.template_editor.views.save'),

                       # NOTE: using the naming convention "fetch" becaues it's remote...? instead of a data structure
#                       (r'^template_editor/fetch_exercises/$', 'fitness.template_editor.views.fetch_exercises'),
                       (r'^template_editor/init/$', 'fitness.template_editor.views.init'),

                       # Admin
                       (r'^admin/(.*)', admin.site.root),
#                       (r'^admin/', include('django.contrib.admin.urls')),

                       (r'^test/(?P<member_id>\d+)/$', 'fitness.workout.views.test'),


                       # Static Content (images, CSS, video, etc.)
#                       (r'^site_media/(?P<path>.*)$', 'django.views.static.serve', {'document_root': '/home/abossy/projects/fitness/media', 'show_indexes': True}),

)

# The following conditional block is to test the JSON being passed through in the calls to "template_editor/init"
if settings.DEBUG:
    urlpatterns += patterns ('',
                             (r'^template_editor/view_save_form/$', 'fitness.template_editor.views.view_save_form'),
                             (r'^template_editor/view_exercise_list/$', 'fitness.template_editor.views.view_exercise_list'),
#                             (r'^template_editor/view_workout_template_list/(?P<collection_id>\d+)/$', 'fitness.template_editor.views.view_workout_template_list'),
                             (r'^template_editor/view_workout_template_list/$', 'fitness.template_editor.views.view_workout_template_list'),
                             (r'^template_editor/view_serialized_form/$', 'fitness.template_editor.views.view_serialized_form'),
                             (r'^template_editor/view_load/$', 'fitness.template_editor.views.view_load'),
                             )


if settings.DEBUG:
    urlpatterns += patterns ('',
                             (r'^media/(?P<path>.*)$', 'django.views.static.serve', {'document_root': settings.MEDIA_ROOT, 'show_indexes': True}),
                             )

if settings.DEBUG:
    urlpatterns += patterns ('',
                             (r'^admin_media/(?P<path>.*)$', 'django.views.static.serve', {'document_root': settings.SITE_ROOT + settings.ADMIN_MEDIA_PREFIX, 'show_indexes': True}),
                             )

#if settings.DEBUG:
#    urlpatterns += patterns ('',
                             # Static Content (images, CSS, video, etc.)
#                             (r'^media/(?P<path>.*)$', 'django.views.static.serve',
#                              {'document_root': '/home/abossy/projects/fitness/media',
#                               'show_indexes': True
#                               }),
#                             )


 
