from dmigrations.mysql.migrations import Migration

migration = Migration(sql_up="", sql_down="")
