from fitness.exercises.models import *
from django.contrib import admin

admin.site.register(ExerciseType)
