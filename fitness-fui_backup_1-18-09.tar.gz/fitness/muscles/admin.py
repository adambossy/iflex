from fitness.muscles.models import *
from django.contrib import admin

admin.site.register(MuscleEntity)

