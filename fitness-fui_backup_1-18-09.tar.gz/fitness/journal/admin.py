from fitness.journal.models import *
from django.contrib import admin

admin.site.register(JournalEntry)
admin.site.register(Pic)
