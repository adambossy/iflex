function addCardioExercise () {

	insertRowExerciseTable ()

}

function addLiftExercise () {

	insertRowExerciseTable ()

}

function insertRowExerciseTable () {

	var exerciseTable = document.getElementById('exerciseTable');

	var newRow = exerciseTable.insertRow();

}